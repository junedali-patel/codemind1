const express = require('express');
const router = express.Router();

// GitHub OAuth configuration (from your .env)
const GITHUB_CLIENT_ID = process.env.GITHUB_CLIENT_ID;
const GITHUB_CLIENT_SECRET = process.env.GITHUB_CLIENT_SECRET;
const REDIRECT_URI = process.env.GITHUB_REDIRECT_URI || 'http://localhost:3000/api/auth/callback';

// Get GitHub OAuth URL
router.get('/github-url', (req, res) => {
  if (!GITHUB_CLIENT_ID) {
    return res.status(500).json({ 
      error: 'GitHub Client ID not configured',
      message: 'Please set GITHUB_CLIENT_ID in .env'
    });
  }

  const githubOAuthUrl = `https://github.com/login/oauth/authorize?client_id=${GITHUB_CLIENT_ID}&redirect_uri=${REDIRECT_URI}&scope=repo,user`;
  
  res.json({ url: githubOAuthUrl });
});

// Handle GitHub OAuth callback
router.get('/callback', async (req, res) => {
  const { code } = req.query;

  if (!code) {
    return res.status(400).json({ error: 'Authorization code not provided' });
  }

  try {
    // Exchange code for access token
    const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        client_id: GITHUB_CLIENT_ID,
        client_secret: GITHUB_CLIENT_SECRET,
        code: code
      })
    });

    const tokenData = await tokenResponse.json();

    if (tokenData.error) {
      throw new Error(tokenData.error_description || 'Failed to get access token');
    }

    const accessToken = tokenData.access_token;

    // Redirect to frontend with token
    // Frontend should store this in localStorage
    res.redirect(`http://localhost:3000/auth-success?token=${accessToken}`);

  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({ error: 'Authentication failed', message: error.message });
  }
});

module.exports = router;
